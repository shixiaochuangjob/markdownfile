package com.jsp.demo02;

import java.io.Serializable;

/**
 * 用户的实体类
 */
public class User implements Serializable {

    private String name = "史小创";
    private int age = 18;
    private Address address = new Address();

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }

}