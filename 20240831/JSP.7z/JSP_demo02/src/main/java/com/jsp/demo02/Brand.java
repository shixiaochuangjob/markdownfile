package com.jsp.demo02;

public class Brand {
    private int id;
    private String brandName;
    private String companyName;
    private int order;
    private String description;
    private int status;

    // Constructors, getters and setters
    public Brand(int id, String brandName, String companyName, int order, String description, int status) {
        this.id = id;
        this.brandName = brandName;
        this.companyName = companyName;
        this.order = order;
        this.description = description;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
