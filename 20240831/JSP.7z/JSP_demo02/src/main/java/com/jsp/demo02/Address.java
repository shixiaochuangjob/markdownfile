package com.jsp.demo02;

import java.io.Serializable;

/**
 * @Author: 史小创
 * @Time: 2024/8/30 下午8:33
 * @Description: 地址的实体类
 */
public class Address implements Serializable {

    private String province = "北京";
    private String city = "昌平区";
    public String getProvince() {
        return province;
    }
    public void setProvince(String province) {
        this.province = province;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
}