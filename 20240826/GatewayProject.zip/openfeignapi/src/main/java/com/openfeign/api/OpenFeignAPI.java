package com.openfeign.api;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 上午10:34
 * @Description:
 */

// @FeignClient(value = "gateway-provider")
@FeignClient(value = "gateway")
public interface OpenFeignAPI {
    @GetMapping("/provider/gateway/getnumber/{id}")
    public String getNumber(@PathVariable("id") Integer id);

    @GetMapping("/provider/gateway/getname/{name}")
    public String getName(@PathVariable("name") String name);
}
