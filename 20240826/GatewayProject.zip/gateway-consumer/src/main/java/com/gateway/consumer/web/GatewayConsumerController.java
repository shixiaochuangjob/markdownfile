package com.gateway.consumer.web;

import com.openfeign.api.OpenFeignAPI;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 下午7:57
 * @Description:
 */

@RestController
@RequestMapping("/consumer/gateway")
public class GatewayConsumerController {
    @Resource
    private OpenFeignAPI openFeignAPI;

    @GetMapping("/getnumber/{id}")
    public String getNumber(@PathVariable("id") Integer id) {
        return openFeignAPI.getNumber(id);
    }

    @GetMapping("/getname/{name}")
    public String getName(@PathVariable("name") String name) {
        return openFeignAPI.getName(name);
    }
}