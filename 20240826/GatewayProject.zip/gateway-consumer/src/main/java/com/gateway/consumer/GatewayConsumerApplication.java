package com.gateway.consumer;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 上午10:20
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.openfeign.api")
public class GatewayConsumerApplication {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(GatewayConsumerApplication.class, args);
    }
}
