package com.gateway.provider;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 下午7:07
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
public class GatewayProviderApplication {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(GatewayProviderApplication.class, args);
    }
}
