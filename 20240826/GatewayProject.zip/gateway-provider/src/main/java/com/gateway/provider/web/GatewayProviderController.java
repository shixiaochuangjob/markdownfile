package com.gateway.provider.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 下午7:09
 * @Description:
 */

@RestController
@RequestMapping("/provider/gateway")
public class GatewayProviderController {

    @GetMapping("/getnumber/{id}")
    public String getNumber(@PathVariable("id") Integer id) {
        return "Hello, provider! inputId:\t" + id + "\t💭💭";
    }

    @GetMapping("/getname/{name}")
    public String getName(@PathVariable("name") String name) {
        return "Hello, provider! inputId:\t" + name + "\t💬💬";
    }
}