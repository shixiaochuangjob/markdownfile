package com.loadbalancer8866.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/26 下午7:18
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
public class LoadbalancerProvider8866Application {
    public static void main(String[] args) {
        SpringApplication.run(LoadbalancerProvider8866Application.class, args);
    }

}
