package com.loadbalancer8877.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/26 下午7:18
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
public class LoadbalancerProvider8877Application {
    public static void main(String[] args) {
        SpringApplication.run(LoadbalancerProvider8877Application.class, args);
    }

}
