package com.loadbalancer.consumer.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * @Author: 史小创
 * @Time: 2024/8/23 下午7:08
 * @Description:
 */

@RestController
public class LoadbalancerConsumerController {
    public static final String URL = "http://LoadbalancerProvider/provider/";

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping(value = "/consumer/{id}")
    public String hello(@PathVariable("id") Integer id) {
        return restTemplate.getForObject(URL + id, String.class);
    }
}
