package com.loadbalancer.consumer.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.loadbalancer.core.RandomLoadBalancer;
import org.springframework.cloud.loadbalancer.core.ReactorLoadBalancer;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import org.springframework.cloud.loadbalancer.support.LoadBalancerClientFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

/**
 * @Author: 史小创
 * @Time: 2024/8/26 下午7:44
 * @Description:
 */


@Configuration
/**
 * @LoadBalancerClient 注解是 Spring Cloud 提供的，用于自定义特定服务的负载均衡配置。
 * value 属性：value = "LoadbalancerProvider" 指定了要为哪个服务自定义负载均衡配置，这里的 "LoadbalancerProvider" 是服务的名称。
 * 这个名称必须与 Consul 或其他服务注册中心中注册的服务名称完全匹配（包括大小写），因为 Spring Cloud 会根据这个名称来查找和应用负载均衡策略。
 *
 * configuration 属性：configuration = RestTemplateConfig.class 指定了该服务的负载均衡配置使用哪个配置类，这里指向的是当前的 RestTemplateConfig 类。
 * 通过这种方式，可以为特定的服务定制负载均衡策略，例如使用随机负载均衡（RandomLoadBalancer）而不是默认的轮询负载均衡（Round Robin）。
 */
@LoadBalancerClient(
        // 下面的value值大小写一定要和consul里面的名字一样，必须一样
        value = "LoadbalancerProvider", configuration = RestTemplateConfig.class)
public class RestTemplateConfig {
    /**
     * 这个注解用于启用客户端负载均衡功能。
     * 注解作用在 RestTemplate 上时，Spring 会为 RestTemplate 配置一个拦截器，
     * 这个拦截器会在你调用服务时自动根据服务名称（例如通过 Consul 注册中心注册的服务名）进行负载均衡。
     * 也就是说，当你在 RestTemplate 中使用服务名称来调用服务时，@LoadBalanced 会确保请求被分发到不同的服务实例上，以实现负载均衡。
     */
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    ReactorLoadBalancer<ServiceInstance> randomLoadBalancer(Environment environment,
                                                            LoadBalancerClientFactory loadBalancerClientFactory) {
        String name = environment.getProperty(LoadBalancerClientFactory.PROPERTY_NAME);

        return new RandomLoadBalancer(loadBalancerClientFactory.getLazyProvider(name, ServiceInstanceListSupplier.class), name);
    }

}
