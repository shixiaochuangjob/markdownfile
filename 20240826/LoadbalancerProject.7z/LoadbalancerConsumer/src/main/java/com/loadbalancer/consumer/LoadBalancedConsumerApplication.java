package com.loadbalancer.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * @Author: 史小创
 * @Time: 2024/8/23 下午6:55
 * @Description: 消费者的启动类
 */

@SpringBootApplication
@EnableDiscoveryClient
public class LoadBalancedConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoadBalancedConsumerApplication.class, args);
    }

}
