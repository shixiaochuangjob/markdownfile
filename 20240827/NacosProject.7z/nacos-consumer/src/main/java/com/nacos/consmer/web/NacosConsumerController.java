package com.nacos.consmer.web;

import cn.hutool.core.util.IdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * @Author: 史小创
 * @Time: 2024/8/27 上午10:28
 * @Description:
 */

@RestController
@RequestMapping("/nacos/consumer")
public class NacosConsumerController {

    private static final String URL = "http://nacos-provider/nacos/provider/id/";

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping(value = "/id/{id}")
    public String hello(@PathVariable("id") Integer id) {
        return restTemplate.getForObject(URL + id, String.class);
    }
}
