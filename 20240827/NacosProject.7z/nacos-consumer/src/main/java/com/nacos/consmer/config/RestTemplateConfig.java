package com.nacos.consmer.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * @Author: 史小创
 * @Time: 2024/8/26 下午7:44
 * @Description:
 */


@Configuration
public class RestTemplateConfig {
    /**
     * 这个注解用于启用客户端负载均衡功能。
     * 注解作用在 RestTemplate 上时，Spring 会为 RestTemplate 配置一个拦截器，
     * 这个拦截器会在你调用服务时自动根据服务名称（例如通过 Consul 注册中心注册的服务名）进行负载均衡。
     * 也就是说，当你在 RestTemplate 中使用服务名称来调用服务时，@LoadBalanced 会确保请求被分发到不同的服务实例上，以实现负载均衡。
     */
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
