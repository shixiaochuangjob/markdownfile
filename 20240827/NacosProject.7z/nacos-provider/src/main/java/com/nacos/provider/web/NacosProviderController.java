package com.nacos.provider.web;

import cn.hutool.core.util.IdUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/27 上午8:47
 * @Description:
 */

@RestController
@RequestMapping("/nacos/provider")
public class NacosProviderController {
    @Value("${server.port}")
    String port;

    @GetMapping(value = "/id/{id}")
    public String hello(@PathVariable("id") Integer id) {
        return "我是服务的提供者，我的端口为：\t" + port + "\t〰〰" + IdUtil.simpleUUID();
    }
}
