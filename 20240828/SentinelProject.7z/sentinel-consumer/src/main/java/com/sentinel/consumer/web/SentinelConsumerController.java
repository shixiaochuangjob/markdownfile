package com.sentinel.consumer.web;

import com.sentinel.feign.SentinelApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/28 下午8:33
 * @Description:
 */

@RestController
public class SentinelConsumerController {
    @Autowired
    private SentinelApi sentinelApi;

    @GetMapping("/rateLimit/doAction/{p1}")
    public String doAction(@PathVariable("p1") Integer p1) {
        return sentinelApi.doAction(p1);
    }
}
