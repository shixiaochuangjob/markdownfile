package com.sentinel.gateway;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/28 下午10:19
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
public class SentinelGatewayApplication {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(SentinelGatewayApplication.class, args);
    }
}
