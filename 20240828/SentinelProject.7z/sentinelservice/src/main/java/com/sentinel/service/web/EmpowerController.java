package com.sentinel.service.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/28 下午6:13
 * @Description: Empower授权规则，用来处理请求的来源
 */

@RestController
public class EmpowerController {
    @GetMapping(value = "/empower")
    public String requestSentinel4() {
        System.err.println("测试Sentinel授权规则empower");
        return "Sentinel授权规则";
    }
}