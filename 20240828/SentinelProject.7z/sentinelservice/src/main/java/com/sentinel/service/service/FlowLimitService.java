package com.sentinel.service.service;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import org.springframework.stereotype.Service;

/**
 * @Author: 史小创
 * @Time: 2024/8/27 下午10:43
 * @Description:
 */

@Service
public class FlowLimitService {

    @SentinelResource(value = "common")
    public void common() {
        System.out.println("------FlowLimitService come in");
    }
}
