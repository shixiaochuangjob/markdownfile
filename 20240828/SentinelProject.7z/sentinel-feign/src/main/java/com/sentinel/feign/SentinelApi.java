package com.sentinel.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "sentinelprovider", fallback = FeignSentinelApiFallBack.class)
public interface SentinelApi {
    @GetMapping("/rateLimit/doAction/{p1}")
    public String doAction(@PathVariable("p1") Integer p1);

}
