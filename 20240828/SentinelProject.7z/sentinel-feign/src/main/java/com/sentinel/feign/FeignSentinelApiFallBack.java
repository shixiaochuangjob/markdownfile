package com.sentinel.feign;

import org.springframework.stereotype.Component;

/**
 * @Author: 史小创
 * @Time: 2024/8/28 下午8:26
 * @Description: 统一服务降级类
 */

@Component
public class FeignSentinelApiFallBack implements SentinelApi {
    @Override
    public String doAction(Integer p1) {
        return "对方服务宕机或不可用，FallBack服务降级o(╥﹏╥)o";
    }
}
