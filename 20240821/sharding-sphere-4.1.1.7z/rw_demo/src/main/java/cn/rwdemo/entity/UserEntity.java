package cn.rwdemo.entity;

import lombok.Data;

@Data
public class UserEntity {

    private Integer userId;

    private String userName;

}