package cn.rwdemo;

import cn.rwdemo.entity.UserEntity;
import cn.rwdemo.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class UserTests {

    @Resource
    private UserMapper userMapper;

    @Test
    public void insertUserInfo() {
        for (int i = 1; i <= 10; i++) {
            UserEntity userEntity = new UserEntity();
            userEntity.setUserId(i);
            userEntity.setUserName("user" + i);
            userMapper.insertUserInfo(userEntity);
        }
    }
	
    @Test
    public void getUserInfo() {
        System.out.println(userMapper.getUserInfo(1));
    }
}