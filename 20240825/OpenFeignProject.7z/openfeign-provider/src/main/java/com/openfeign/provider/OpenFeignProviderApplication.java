package com.openfeign.provider;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 上午10:20
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
public class OpenFeignProviderApplication {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(OpenFeignProviderApplication.class, args);
    }
}
