package com.openfeign.provider.web;

import cn.hutool.core.util.IdUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.TimeUnit;

/**
 * @Author: 史小创
 * @Time: 2024/8/23 下午6:47
 * @Description:
 */

@RestController
public class ProviderController {
    @Value("${server.port}")
    String port;


  /*  @GetMapping("/provider")
    public String helloWorld(@RequestParam("name") String name) {
        return "hello " + name + ",i am from port:" + port + "🔊" + IdUtil.simpleUUID();
    }*/

    @GetMapping("/provider")
    public String helloWorld(@RequestParam("name") String name) {
        // 暂停62秒钟线程,故意写bug，测试出feign的默认调用超时时间
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return "hello " + name + ",i am from port:" + port + "🔊" + IdUtil.simpleUUID();
    }

}
