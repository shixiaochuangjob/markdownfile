package com.openfegin.consumer;

import com.openfeign.api.OpenFeignAPI;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 上午10:20
 * @Description:
 */

@SpringBootApplication
@EnableDiscoveryClient
// @EnableFeignClients
@EnableFeignClients(basePackages = "com.openfeign.api")
// @EnableFeignClients(clients = OpenFeignAPI.class)
public class OpenFeignConsumerApplication {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(OpenFeignConsumerApplication.class, args);
    }
}
