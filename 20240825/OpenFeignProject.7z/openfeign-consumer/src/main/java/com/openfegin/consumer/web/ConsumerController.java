package com.openfegin.consumer.web;

import cn.hutool.core.date.DateUtil;
import com.openfeign.api.OpenFeignAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/23 下午7:08
 * @Description:
 */

@RestController
public class ConsumerController {
    @Autowired
    private OpenFeignAPI openFeignAPI;

    @Value("${server.port}")
    String port;

  /*  @GetMapping("/consumer")
    public String hello(@RequestParam("name") String name) {
        return openFeignAPI.helloWorld(name) + "消费者的端口号\n" + port;
    }*/

    @GetMapping("/consumer")
    public String hello(@RequestParam("name") String name) {
        String result = null;
        try {
            System.out.println("调用开始-----: " + DateUtil.now());
            return openFeignAPI.helloWorld(name) + "消费者的端口号\n" + port;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("调用结束-----: " + DateUtil.now());
        }

        return result;
    }

}
