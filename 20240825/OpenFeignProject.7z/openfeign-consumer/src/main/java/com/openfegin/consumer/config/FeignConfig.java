package com.openfegin.consumer.config;

import feign.Logger;
import feign.Retryer;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 下午2:42
 * @Description:
 */

@Configurable
public class FeignConfig {

    @Bean
    public Retryer myRetryer() {
        // return Retryer.NEVER_RETRY; // Feign默认配置是不走重试策略的

        // 最大请求次数为3(1+2)，初始间隔时间为100ms，重试间最大间隔时间为1s
        return new Retryer.Default(100, 1, 3);
    }

    @Bean
    Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }
}
