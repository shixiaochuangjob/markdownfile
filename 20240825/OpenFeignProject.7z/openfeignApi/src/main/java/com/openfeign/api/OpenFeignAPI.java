package com.openfeign.api;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @Author: 史小创
 * @Time: 2024/8/25 上午10:34
 * @Description:
 */

@FeignClient(value = "openfeign-provider")
public interface OpenFeignAPI {
    @GetMapping("/provider")
    public String helloWorld(@RequestParam("name") String name);
}
