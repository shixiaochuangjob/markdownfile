package com.resilience4j.consumer.web;

import com.resilience4j.feginapi.apis.FeignAPI;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 史小创
 * @Time: 2024/8/24 下午12:48
 * @Description:
 */

@RestController
public class Resilience4JConsumerController {
    @Resource
    private FeignAPI feignAPI;

    @GetMapping(value = "/consumer/circuit/{id}")
    public String myCircuitBreaker(@PathVariable("id") Integer id) {
        return feignAPI.myCircuit(id);
    }


}
