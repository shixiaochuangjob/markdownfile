package com.resilience4j.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @Author: 史小创
 * @Time: 2024/8/24 上午10:38
 * @Description: 服务提供者的启动类
 */

@SpringBootApplication
@EnableDiscoveryClient
public class Resilience4JProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(Resilience4JProviderApplication.class, args);
    }
}
