package com.resilience4j.feginapi.apis;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @Author: 史小创
 * @Time: 2024/8/24 上午11:10
 * @Description:
 */

@FeignClient(value = "resilience4j-provider")
public interface FeignAPI {

    @GetMapping(value = "/provider/circuit/{id}")
    public String myCircuit(@PathVariable("id") Integer id);

    @GetMapping(value = "/provider/bulkhead/{id}")
    public String myBulkhead(@PathVariable("id") Integer id);

    @GetMapping(value = "/provider/ratelimit/{id}")
    public String myRatelimit(@PathVariable("id") Integer id);
}
