package com.resilience4j.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @Author: 史小创
 * @Time: 2024/8/24 下午12:43
 * @Description:
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.resilience4j.feginapi.apis"})
public class Resilience4JConsumerApplication {
    public static void main(String[] args) {
        SpringApplication.run(Resilience4JConsumerApplication.class, args);
    }
}